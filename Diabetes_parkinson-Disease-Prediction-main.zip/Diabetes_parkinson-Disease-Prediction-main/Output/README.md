# 1. Trained Model with Jupyter Notebook

  ![Diabetes](https://github.com/NithinU2802/Diabetes_parkinson-Disease-Prediction/assets/106614289/baf657a6-c7fc-4b26-aaa3-cb6d4afc0f14)

# 2. UI Outcome with Streamlit

  ![Screenshot (399)](https://github.com/NithinU2802/Diabetes_parkinson-Disease-Prediction/assets/106614289/d11acf45-7ec0-40ea-95ba-9f40a8dc6ae9)
